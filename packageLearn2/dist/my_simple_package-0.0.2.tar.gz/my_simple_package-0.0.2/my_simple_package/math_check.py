def add_num(x, y):
    return x + y


def sub_num(x, y):
    return x - y
